# LibraryProgram-Netbeans

Ky eshte nje program i krijuar ne Netbeans . Qellimi i ketij programi eshte krijimi i nje biblioteke online , ku perdoruesit mund te zgjedhin libra per te lexuar nga aty ose mund te shtojne ndonje liber te ri tek arkiva e librave .
