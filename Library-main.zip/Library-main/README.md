# Library

Ky program eshte i krijuar ne Java , krijimi i nje biblioteke e cila ka lloje te ndryshme librash brenda saj me specifikat e tyre. 
Kemi klasen main e cila ruan te dhenat te cilat do afishohen ne menyre te strukturuar dhe merren me ane te trashegimise . 
Pervec klases main jane te krijuara dhe disa klasa te cilat perdoren per te afishuar ne menyre te vecante nje tip specifik te nje libri .
Po ashtu afishohet dhe dita kur merret dhe kur duhet te dorezohet libri .
